<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Seeder;

class cityTableseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $json = Storage::disk('local')->get('data/countries+states+cities.json');  // Make sure the path is correct
        $cities = json_decode($json, true);
    
        // Loop through the cities and insert/update them in the database
        foreach ($cities as $city) {
            // Use the appropriate model method to insert or update records
            City::insert([
                'name' => $city['name'],
                'latitude' => $city['latitude'],
                'longitude' => $city['longitude'],
                'state_id' => $city['state_id'], 
            ]);
        }
    }
}
