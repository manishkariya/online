
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>updateus</title>
</head>
<body>
  
<section>
      <div class="container-lg">
        <div class="text-dark py-5 my-5">
          <div class="container shadow">
            <div class="row justify-content-center">
              <div class="col-md-5 p-3">
                <div class="section-header text-dark">
                  <h2 class="section-title display-5 text-dark">update</h2>
                </div>
                <p>Just Sign Up & Register it now to become member.</p>
                <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14766.779052283493!2d70.7472124554199!3d22.28954949999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959cb5accd58677%3A0x66e11372ab01cd25!2sGurudev%20Organics!5e0!3m2!1sen!2sin!4v1731125500850!5m2!1sen!2sin" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
              </div>
              <div class="col-md-5 p-3">
                <form action="<?php echo e(route('update.user',$data->id)); ?>" method="POST"  class="text-dark mt-5">
                  <?php echo csrf_field(); ?>
                  <div class="mb-3">
                    <label for="name" class="form-label d-none text-dark">Name</label>
                    <input type="text" value="<?php echo e($data->name); ?>"
                      class="form-control form-control-md rounded-0 border border-2 border-dark"  name="name" id="name" placeholder="Name">
                  </div>
                  <div class="mb-3">
                    <label for="email" class="form-label d-none">Email</label>
                    <input type="email" value="<?php echo e($data->email); ?>" class="form-control form-control-md rounded-0 border border-2 border-dark"  name="email" id="email" placeholder="Email Address">
                  </div>

                  <div class="mb-3">
                    <label for="email" class="form-label d-none">Phone</label>
                    <input type="text"value="<?php echo e($data->phone); ?>" class="form-control form-control-md rounded-0 border border-2 border-dark"  name="phone" id="email" placeholder="Phone">
                  </div>

                  

                  <div class="mb-3">
                    <label for="email" class="form-label d-none">Subject</label>
                    <input type="text"value="<?php echo e($data->subject); ?>" class="form-control form-control-md rounded-0 border border-2 border-dark"  name="subject" id="email" placeholder="Subject">
                  </div>


                  <div class="mb-3">
                    <label for="email" class="form-label d-none">Message</label>
                    <textarea  class="form-control form-control-md rounded-0 border border-2 border-dark"  name="address" id="email" placeholder="Address"><?php echo e($data->email); ?></textarea>
                  </div>

               

                  <div class="mb-3">
    <select name="country" id="country" class="form-control form-control-md rounded-0 border border-2 border-dark">
        <option value="<?php echo e($data->country); ?>">Select Country</option>
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($country->id); ?>" <?php echo e($data->country == $country->id ? 'selected' : ''); ?>>
                <?php echo e($country->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>                      <div class="mb-3 mt-3">

    <select name="state" id="state" class="form-control form-control-md rounded-0 border border-2 border-dark">
        <option value="<?php echo e($data->state); ?>">Select state</option>
        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($state->id); ?>" <?php echo e($data->state == $state->id ? 'selected' : ''); ?>>
                <?php echo e($state->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
                            </div>

                            <!-- City Dropdown  -->
                            <div class="mb-3 mt-3">
                               
                            <select name="city" id="city" class="form-control form-control-md rounded-0 border border-2 border-dark">
        <option value="<?php echo e($data->city); ?>">Select city</option>
        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($city->id); ?>" <?php echo e($data->city == $city->id ? 'selected' : ''); ?>>
                <?php echo e($city->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
                            </div>
                  <div class="d-grid gap-2">
                    <button type="submit"  class="btn btn-dark btn-md rounded-0">Submit</button>
                  </div>
                </form>
                <?php if(session('success')): ?>
    <script>
        alert("<?php echo e(session('success')); ?>");
    </script>
<?php endif; ?> 

<?php if(session('error')): ?>
    <script>
        alert("<?php echo e(session('error')); ?>");
    </script>
<?php endif; ?>
              </div>
              
            </div>
            
          </div>
        </div>
        
      </div>
    </section> 
    
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
  
        $('#country').change(function() {
            var country_id = $(this).val();
            if (country_id) {
                $.ajax({
                    url: '/get-states/' + country_id,  
                    type: 'GET',
                    success: function(data) {
                        $('#state').html('<option value="">Select State</option>');
                        $.each(data, function(index, state) {
                            $('#state').append('<option value="' + state.id + '">' + state.name + '</option>');
                        });
                    }
                });
            } else {
                $('#state').html('<option value="">Select State</option>');
            }
        });

        $('#state').change(function() {
            var state_id = $(this).val();
            if (state_id) {
                $.ajax({
                    url: '/get-cities/' + state_id,  
                    type: 'GET',
                    success: function(data) {
                        $('#city').html('<option value="">Select City</option>');
                        $.each(data, function(index, city) {
                            $('#city').append('<option value="' + city.id + '">' + city.name + '</option>');
                        });
                    }
                });
            } else {
                $('#city').html('<option value="">Select City</option>');
            }
        });
    });
</script>
   

</body>
</html>
<?php /**PATH C:\xampp\crud-op\resources\views/update.blade.php ENDPATH**/ ?>