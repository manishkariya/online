<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Show</title>
</head>
<body>
    <div class="container-fluid mt-5 mb-4">
        <div class="row justify-content-center">
            <h1 class="text-center" style="display: inline-block;">All Users Data</h1>
            
            <div class="col-12 col-md-10">
                <!-- Search Form and Add Data button aligned in the same row -->
                <div class="d-flex justify-content-between mb-3">
                    <form method="GET" action="<?php echo e(route('search.users')); ?>" class="d-flex">
                        <input type="text" name="search" class="form-control" placeholder="Search..." value="<?php echo e(request()->get('search')); ?>">
                        <button type="submit" class="btn btn-info ms-2">Search</button>
                    </form>
                    <a href="/newuser">
                        <button type="submit" class="btn btn-primary btn-md rounded-0" style="display: inline-block; margin-left: auto; margin-right: 0;">
                            Add Data
                        </button>
                    </a>
                </div>

                <!-- Show alert if no records found -->
                <?php if($data->isEmpty()): ?>
                    <div class="alert alert-danger" role="alert">
                        No records found.
                    </div>
                <?php else: ?>
                    <!-- Show the table if records are found -->
                    <table class="table table-bordered table-striped text-center">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>name</th>
                                <th>email</th>
                                <th>phone</th>
                                <th>subject</th>
                                <th>address</th>
                                <th>country</th>
                                <th>state</th>
                                <th>city</th>
                                <th>update</th>
                                <th>delete</th>
                                <th>view</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->subject); ?></td>
                                <td><?php echo e($user->address); ?></td>
                                <td><?php echo e($user->country); ?></td>
                                <td><?php echo e($user->state); ?></td>
                                <td><?php echo e($user->city); ?></td>
                                <td><a href="<?php echo e(route('update.page', $user->id)); ?>"><button type="submit" class="btn btn-success btn-md rounded-0">Update</button></a></td>
                                <td><a href="<?php echo e(route('delete.user', $user->id)); ?>"><button type="submit" class="btn btn-danger btn-md rounded-0">Delete</button></a></td>
                                <td><a href="<?php echo e(route('view.user', $user->id)); ?>"><button type="submit" class="btn btn-primary btn-md rounded-0">View</button></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <!-- Centered Pagination -->
                <div class="text-center">
                    <?php echo e($data->links()); ?>

                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\crud-op\resources\views/show.blade.php ENDPATH**/ ?>