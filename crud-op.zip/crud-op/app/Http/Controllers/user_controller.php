<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
  

class user_controller extends Controller
{


  public function index(Request $request)
  {
    $searchTerm = $request->get('search');
    
    // Query the database to filter the users based on the search term
    if ($searchTerm) {
        $data = DB::table('user')->where('name', 'like', '%' . $searchTerm . '%')
                    ->orWhere('email', 'like', '%' . $searchTerm . '%')
                    ->orWhere('phone', 'like', '%' . $searchTerm . '%')
                    ->orWhere('subject', 'like', '%' . $searchTerm . '%')
                    ->orWhere('address', 'like', '%' . $searchTerm . '%')
                    ->orWhere('city', 'like', '%' . $searchTerm . '%')
                    ->orWhere('state', 'like', '%' . $searchTerm . '%')
                    ->orWhere('country', 'like', '%' . $searchTerm . '%')
                    ->paginate(10);
    } else {
        // If no search term is provided, show all users
        $data = DB::table('user')->paginate(10);
    }

    // Pass a flag to indicate whether any records were found
    $noRecordsFound = $data->isEmpty();
    
    // Pass both the data and the noRecordsFound flag to the view
    return view('show', compact('data', 'noRecordsFound'));
  }
//   public function addUser(Request $request)
// {
//     // Validate the input
//     \Log::info('User data being inserted: ', $request->all());
//     $request->validate([
//         'name' => 'required|string|max:255',
//         'email' => 'required|email|unique:users,email', // This checks if email is unique
//         'phone' => 'required|string|max:10',
//         'subject' => 'required|string|max:255',
//         'address' => 'required|string|max:1000',
//         'contry' => 'required|string|max:255',
//         'state' => 'required|string|max:255',
//         'city' => 'required|string|max:255',
//     ]);

//     // If validation passes, create the user
//     try {
//         $user = DB::table('user')->insert([
//             'name' => $request->name,   
//             'email' => $request->email,
//             'phone' => $request->phone,
//             'subject' => $request->subject,
//             'address' => $request->address,
//            // dropdown tag
//             'contry' => $request->contry,
//             'state' => $request->state,
//             'city' => $request->city,
          
//         ]);
      
//         return redirect()->route('home')->with('success', 'User registered successfully!');
//         \Log::error('Error inserting user: ' . $e->getMessage());
//     } catch (\Exception $e) {
//         return redirect()->back()->with('error', 'email address is alrady exist plz chang him');
//     }
// }


public function addUser(Request $req)
{
    // Fetch the country, state, and city names based on their IDs
    $countryName = DB::table('countries')->where('id', $req->country)->value('name');
    $stateName = DB::table('states')->where('id', $req->state)->value('name');
    $cityName = DB::table('cities')->where('id', $req->city)->value('name');

    // Insert the user data with the country, state, and city names
    $user = DB::table('user')->insert([
        'name' => $req->name,
        'email' => $req->email,
        'phone' => $req->phone,
        'subject' => $req->subject,
        'address' => $req->address,
        'country' => $countryName, // Store the actual country name
        'state' => $stateName,     // Store the actual state name
        'city' => $cityName,       // Store the actual city name
    ]);

    if ($user) {
        return redirect()->route('home');
    } else {
        return redirect()->back()->with('error', 'Not added');
    }
}

  // public function addUser(Request $req){
  //   $user = DB::table('user')->insert([
  //   'name'=>$req->name,
  //   'email'=>$req->email,
  //   'phone'=>$req->phone,
  //   'subject'=>$req->subject,
  //   'address'=>$req->address,
  // //  'country_id' => $req->country_id, // Save the country ID
  // //       'state_id' => $req->state_id,     // Save the state ID
  // //       'city_id' => $req->city_id,  
  //   'country' => $req->country,
  //              'state' => $req->state,
  //               'city' => $req->city,
             
  //           ]);
  

  //   if($user){
  //     return redirect()->route('home');
  // }
  // else{
  //     return redirect()->back()->with('error', 'Not added');
  // }

  // }   

  
 public function showuser(){
    $user= DB::table('user')->simplePaginate(4); 

    return view('show',['data'=>$user]);
    
    
      }

      public function updateUser(Request $req, $id)
      {
          // Fetch the country, state, and city names based on their IDs
          $countryName = DB::table('countries')->where('id', $req->country)->value('name');
          $stateName = DB::table('states')->where('id', $req->state)->value('name');
          $cityName = DB::table('cities')->where('id', $req->city)->value('name');
      
          // Update the user data with the country, state, and city names
          $user = DB::table('user')->where('id', $id)->update([
              'name' => $req->name,
              'email' => $req->email,
              'phone' => $req->phone,
              'subject' => $req->subject,
              'address' => $req->address,
              'country' => $countryName, // Store the actual country name
              'state' => $stateName,     // Store the actual state name
              'city' => $cityName,       // Store the actual city name
          ]);
      
          if ($user) {
              return redirect()->route('home');
          } else {
              return redirect()->back()->with('error', 'Not updated');
          }
      }
      // public function updateUser(Request $req,$id){


// $user = DB::table('user')->where('id',$id)->update([
//   'name'=>$req->name,
//   'email'=>$req->email,
//   'phone'=>$req->phone,
//   'subject'=>$req->subject,
//   'address'=>$req->address,
//       // dropdown tag 
//   'country' => $req->name,
//                'state' => $req->name,
//                 'city' => $req->name,
// ]);

//   if($user){
//     return redirect()->route('home');
// }
// else{
//     return redirect()->back()->with('error', 'Not added');
// }
// }
      
//   public function updatePage(string $id){
// $user= DB::table('user')->find($id);

// return view('update',['data'=>$user]);


  
 
// }

public function updatePage(string $id){
  $user = DB::table('user')->find($id);
  $countries = DB::table('countries')->get(); // Fetch countries
  $states = DB::table('states')->get();
  $cities = DB::table('cities')->get();


  return view('update', ['data' => $user, 'countries' => $countries,'states' => $states,'cities' => $cities]);
}

public function singleUser(string $id){
  $user = DB::table('user')->where('id', $id)->get();  // Fetch the users from DB by their IDs
  return view('singleview', ['data'=>$user]);

}


public function deleteUser(string $id){
  $user = DB::table('user')->where('id',$id)->delete();

  if($user){
      return redirect('/');
  }
}


/////// add data for dropdown dynamic menu
public function showContactUsForm()
{
    // Debugging: Check if method is executed
   // dd('Controller method is being called!');

    // Your data fetching logic
    $countries = DB::table('countries')->get(); 
    $states = DB::table('states')->get();
    $cities = DB::table('cities')->get();

    
    return view('contactus', compact('countries', 'states', 'cities'));
}



public function getStates($country_id)
{
    $states = DB::table('states')->where('country_id', $country_id)->get();
    return response()->json($states);
}

public function getCities($state_id)
{
    $cities = DB::table('cities')->where('state_id', $state_id)->get();
    return response()->json($cities);
}


}
