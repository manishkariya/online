<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>show</title>
</head>
<body>
<div class="container mt-5  ">
      <div class="row d-flex justify-content-center ">
        <h1 class="row d-flex justify-content-center " > user details</h1>
        <div class="col-6"> 

          <table class="table table-bordered table-striped">
            <th>id</th>
            <th>name</th>
           <th>email</th>
           <th>phone</th>
           <th>subject</th>
           <th>address</th>
           <th>country</th>
            <th>state</th>
           <th>city</th>
            @foreach ($data as $id => $user )
            <tr>
              <td>  {{ $user->id}} </td>
              <td>  {{ $user->name}} </td>
              <td>{{ $user->email}}</td>
              <td> {{ $user->phone}}</td>
              <td>{{ $user->subject}}</td>
              <td>{{ $user->address}}</td>
              <td>{{ $user->country }}</td>
                <td>{{ $user->state }}</td>
            <td>{{ $user->city }}</td>
            </tr>
            @endforeach
          </table>
          <div>
        
          </div>
          <a href="/" ><button type="submit"  class="btn btn-primary btn-md rounded-0 mt-3  ">BackTopage</button></a>
        </div >
        <div >
       
      </div>
      </div>
      
    </div>



</body>
</html>
